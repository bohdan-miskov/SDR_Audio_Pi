# --- Базові параметри SDR-приймача ---

SAMPLE_RATE = 30000000   # 30 MSPS
BUFFER_SIZE = 65356      # Розмір буфера IQ (для якісного FFT)
GAIN_DEFAULT = 50        # Посилення за замовчуванням, dB

# Поріг виявлення сигналу (дБ над рівнем шуму)
RSSI_THRESHOLD = 15

# Зміщення для кодування PSD (dB) у uint8:
# value_uint8 = clip(round(dB + DB_OFFSET), 0, 255)
# Декодування: dB = value_uint8 - DB_OFFSET
# Діапазон покриття: [-100, +155] dBm → [0, 255]
DB_OFFSET = 100
